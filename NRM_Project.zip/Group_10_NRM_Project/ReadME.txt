						----------Read me-------------

1) The main code to run is named 'Project_code.m'.

2) Running the code again might produce slightly different results than those shown in the report 
	as they are ANN and EA modles which evolve with each run.

3)  The code is divided in two parts and is written such that each part can be run separately or together. 

% LABORATORY OF NATURAL RESOURCES MANAGEMENT - group10  Linear Models
clear
close all

%  --------------------
%%  LOAD AND PLOT DATA
%  --------------------
% loading and plotting respective data

data = readmatrix('10Freudenau.csv'); 
% 29 Feb already removed from leap years

%average daily precipitation (mm/d)
P = data(:,4); 
plot(P,'.')
xlabel('time [days]')
ylabel('Precipitation (mm/d)')
title('Daily precipitation (1990-2016)')
figure;

%average daily inflow [m^3/s] 
Q = data(:,5); 
plot(Q,'.')
xlabel('time [days]')
ylabel('Inflow (m^3/s)')
title('Daily inflow (1990-2016)')
figure;

%average daily temperature (°C)
T1 = data(:,6); 
plot(T1,'.')
xlabel('time [days]')
ylabel('Temperature (°C)')
title('Daily temperature (1990-2016)')

% load data                 %%%%%( average daily inflow [m3/s] )
%load -ascii group10_1990_2016_nb.txt;
%% defining training dataset for 15 years and validation for 12 years


q = Q(1:365*15);
qv = Q(365*15+1:end);
p = P(1:365*15);
pv = P(365*15+1:end);
t = T1(1:365*15);
tv = T1(365*15+1:end);

% Training dataset
% plot time-series for training
N = length(q);
ts = [1 : N]'; %#ok<*NBRAK> % indices t = 1 , 2 , ... , 365 , 366 , 367 , ...
figure
plot(ts, q)
xlabel('time [days]')
ylabel('inflow [m^3/s]')
figure
plot(ts, p)
xlabel('time [days]')
ylabel('precipitation [mm/d]')
figure
plot(ts, t)
xlabel('time [days]')
ylabel('temperature [°C]')

% statistics (uncomment to get these statistics)
%q_min   = min(q);
%q_max   = max(q);
%q_range = q_max - q_min;
%q_mean  = mean(q);
%q_var   = var(q);
%p_min   = min(p);
%p_max   = max(p);
%p_range = p_max - p_min;
%p_mean  = mean(p);
%p_var   = var(p);
%t_min   = min(t);
%t_max   = max(t);
%t_range = t_max - t_min;
%t_mean  = mean(t);
%t_var   = var(t);



%  ------------------------------------------
%  CYCLOSTATIONARY MEAN AND VARIANCE - EX 1
%  ------------------------------------------

% periodicity 
Td  = 365; % period (days)


tt = repmat( [1:365]' , N/Td, 1 ) ;
% indices tt = 1 , 2 , ... , 365 , 1 , 2 , ...
%tt = mod(t - 1 , T) + 1   ;
% indices tt = 1 , 2 , ... , 365 , 1 , 2 , ...

figure
plot(tt, q, '.')
xlabel('time (1 year) [days]')
ylabel('inflow [m^3/s]')

% reshape the vector q containing the inflow data
Qd = reshape(q, Td, 15);
% cyclo-stationary mean
Cm = mean(Qd, 2); % Cm = mean(Qd')';
% cyclo-stationary variance
Cv = var(Qd, 0, 2); %#ok<NASGU> % Cv = var(Qd')';

% graphical analysis
figure
plot(tt, q, '.')
hold on
plot(Cm, 'r', 'LineWidth', 2)
legend('observed flow', 'cyclo mean')
xlabel('time (1 year) [days]')
ylabel('flow [m^3/s]')

%  -----------------------------

%% Training dataset cyclostationary values, deseasonilized values
[mi_q, m_q] = moving_average(q, Td, 5);
figure
plot(tt, q, '.')
hold on
plot([1 : Td], mi_q, 'r', 'LineWidth', 2)
xlabel('time (1 year)')
ylabel('Inflow [m^3/s] ')
legend('observed flow q_t', 'moving cyclo mean \mu_t', ...
    'location', 'best')

[mi_p, m_p] = moving_average(p, Td, 5);
figure
plot(tt, p, '.')
hold on
plot([1 : Td], mi_p, 'b', 'LineWidth', 2)
xlabel('time (1 year)')
ylabel('Precipitaion [mm/d]')
legend('observed precpitation p_ts', 'moving cyclo mean \mu_ts', ...
    'location', 'best')

[mi_t, m_t] = moving_average(t, Td, 5);
figure
plot(tt, t, '.')
hold on
plot([1 : Td], mi_t, 'g', 'LineWidth', 2)
xlabel('time(1 year)')
ylabel('Temperature [°C] ')
legend('observed temperature t_ts', 'moving cyclo mean \mu_ts', ...
    'location', 'best')


% compute and plot periodic std
[sigma2_q, s2_q] = moving_average( ( q - m_q ).^2, Td, 5);
sigma_q        = sigma2_q.^0.5;
s_q            = s2_q.^0.5;

[sigma2_p, s2_p] = moving_average( ( p - m_p ).^2, Td, 5);
sigma_p        = sigma2_p.^0.5;
s_p            = s2_p.^0.5;

[sigma2_t, s2_t] = moving_average( ( t - m_t ).^2, Td, 5);
sigma_t        = sigma2_t.^0.5;
s_t            = s2_t.^0.5;

% deseasonalized inflow
x = (q - m_q) ./ s_q;
figure
plot(x)
xlabel('time t')
ylabel('deseasonalized inflow [m^3/s] (1990-2004)')

% deseasonalized precipitation
u = (p-m_p) ./ s_p; 
figure
plot(u)
xlabel('time t')
ylabel('deseasonalized precipitation [mm/d] (1990-2004)')

% deseasonalized temperature
z = (t - m_t)./s_t; 
figure
plot(z)
xlabel('time t (1 year)')
ylabel('deseasonalized temperature [°C] (1990-2004)')
% COMMENT : periodicity has been (partially) removed

%% Validation dataset cyclostationary values, deseasonilized values

% Validation dataset
% plot time-series for validation
Nv = length(qv);
tsv = [1 : Nv]'; % indices t = 1 , 2 , ... , 365 , 366 , 367 , ...
figure
plot(tsv, qv)
xlabel('time [days]')
ylabel('inflow [m^3/s]')
figure
plot(tsv, pv)
xlabel('time [days]')
ylabel('precipitation [mm/d]')
figure
plot(tsv, tv)
xlabel('time [days]')
ylabel('temperature [°C]')

% statistics (uncomment to get these statistics)
%qv_min   = min(qv);
%qv_max   = max(qv);
%qv_range = qv_max - qv_min;
%qv_mean  = mean(qv);
%qv_var   = var(qv);
%pv_min   = min(pv);
%pv_max   = max(pv);
%pv_range = pv_max - pv_min;
%pv_mean  = mean(pv);
%pv_var   = var(pv);
%tv_min   = min(tv);
%tv_max   = max(tv);
%tv_range = tv_max - tv_min;
%tv_mean  = mean(tv);
%tv_var   = var(tv);

ttv = repmat( [1:365]' , Nv/Td, 1 ) ;

figure
plot(ttv, qv, '.')
xlabel('time (1 year) [days]')
ylabel('inflow [m^3/s]')

% reshape the vector q containing the inflow data
Qdv = reshape(qv, Td, 12);
% cyclo-stationary mean
Cm = mean(Qdv, 2); % Cm = mean(Qdv')';
% cyclo-stationary variance
Cv = var(Qdv, 0, 2); % Cv = var(Qdv')';

% graphical analysis
figure
plot(ttv, qv, '.')
hold on
plot(Cm, 'r', 'LineWidth', 2)
legend('observed flow', 'cyclo mean')
xlabel('time (1 year) [days]')
ylabel('inflow [m^3/s]')


[mi_qv, m_qv] = moving_average(qv, Td, 5);
figure
plot(ttv, qv, '.')
hold on
plot([1 : Td], mi_qv, 'r', 'LineWidth', 2)
xlabel('time (1 year)')
ylabel('Inflow [m^3/s] ')
legend('observed flow qv_t', 'moving cyclo mean \mu_t', ...
    'location', 'best')

[mi_pv, m_pv] = moving_average(pv, Td, 5);
figure
plot(ttv, pv, '.')
hold on
plot([1 : Td], mi_pv, 'b', 'LineWidth', 2)
xlabel('time (1 year)')
ylabel('Precipitaion [mm/d]')
legend('observed precpitation pv_ts', 'moving cyclo mean \mu_ts', ...
    'location', 'best')

[mi_tv, m_tv] = moving_average(tv, Td, 5);
figure
plot(ttv, tv, '.')
hold on
plot([1 : Td], mi_tv, 'g', 'LineWidth', 2)
xlabel('time(1 year)')
ylabel('Temperature [°C] ')
legend('observed temperature tv_ts', 'moving cyclo mean \mu_ts', ...
    'location', 'best')


% compute and plot periodic std
[sigma2_qv, s2_qv] = moving_average( ( qv - m_qv ).^2, Td, 5);
sigma_qv        = sigma2_qv.^0.5;
s_qv            = s2_qv.^0.5;

[sigma2_pv, s2_pv] = moving_average( ( pv - m_pv ).^2, Td, 5);
sigma_pv        = sigma2_pv.^0.5;
s_pv            = s2_pv.^0.5;

[sigma2_tv, s2_tv] = moving_average( ( tv - m_tv ).^2, Td, 5);
sigma_tv        = sigma2_tv.^0.5;
s_tv            = s2_tv.^0.5;

% deseasonalized inflow
xv = (qv - m_qv) ./ s_qv;
figure
plot(xv)
xlabel('time t')
ylabel('deseasonalized inflow [m^3/s] (2005-2016)')

% deseasonalized precipitation
uv = (pv-m_pv) ./ s_pv; 
figure
plot(uv)
xlabel('time t')
ylabel('deseasonalized precipitation [mm/d] (2005-2016)')

% deseasonalized temperature
zv = (tv - m_tv)./s_tv; 
figure
plot(zv)
xlabel('time t (1 year)')
ylabel('deseasonalized temperature [°C] (2005-2016)')



%  -----------------
%%  AUTOCORRELATION 
%  -----------------

figure
correlogram(x, x, 10);
xlabel('k')
ylabel('r_k')
% COMMENT : it is not white and we can notice some peaks
% (with period 7) that are due to upstream hydropower
% releases (this deterministic behavior was not removed).




%%  AR(1) 
%  --------------------------
% AR(1) calibration 
%  --------------------------

y     = x(2 : end);
M1c     = [x(1 : end - 1)];
theta1 = M1c \ y;  
x1c    = M1c * theta1;
x1c    = [x(1) ; x1c];
q1c    = x1c .* s_q + m_q;

figure 
plot([ q q1c ], '.-')
xlabel( 'time t [days]' ); ylabel( '[m^3/s]' )
legend( 'observed', 'predicted' )
% well-known problems of AR: peaks are underestimated
% and the predictions have a delay wrt the observations

e = q(2:end) - q1c(2:end);
figure
correlogram(e, e, 20);
xlabel('k'); ylabel('r_k')
% Mean Squared Error (MSE)
Qc = mean( e.^2 ) 
% coefficient of determination (R2)
R2_A1 = 1 - sum((q(2:end)-q1c(2:end)).^2) / sum((q(2:end)-m_q(2:end)).^2) 



%  ------------------
% AR(1) validation
%  ------------------

% [mi_qv, m_qv] = moving_average(qv, T, 5);
% [sigma2_qv, s2_qv] = moving_average( ( qv - m_qv ).^2, T, 5);
% s_qv = s2_qv .^ 0.5;

M1v     = [xv(1 : end - 1)]; 
x1v    = M1v * theta1;
x1v    = [xv(1) ; x1v];
q1v    = x1v .* s_qv + m_qv;

ev = qv(2:end) - q1v(2:end);
figure
correlogram(ev, ev, 20);
xlabel('k'); ylabel('r_k')

Qv = mean( ev.^2 )                                                                                 %#ok<*NOPTS>
R2_A1v = 1 - sum((qv(2:end)-q1v(2:end)).^2) / sum((qv(2:end)-m_qv(2:end)).^2)



%  -----------------------------
%%  AR(2) 
%  -----------------------------

% AR(2) calibration 
M2c     = [ x(1:end-2), x(2:end-1) ];
theta2  = M2c \ x(3:end);
xc_2    = M2c * theta2;
xc_2    = [ x(1:2); xc_2 ];
qc_2    = xc_2 .* s_q + m_q;

e2 = q(3:end) - qc_2(3:end);

figure;
correlogram(e2,e2,20);
R2c_2 = 1 - sum((q(3:end)-qc_2(3:end)).^2) / sum((q(3:end)-m_q(3:end)).^2)    

% AR(2) validation
M2v  = [ xv(1:end-2), xv(2:end-1) ];
xv_2 = M2v * theta2;
xv_2 = [ xv( 1:2 ); xv_2 ];
qv_2 = xv_2 .* s_qv + m_qv;

R2v_2 = 1 - sum((qv(3:end)-qv_2(3:end)).^2) / ...
    sum((qv(3:end)-m_qv(3:end)).^2 )   


%  ----------------------
%%  AR(3) 
%  ----------------------

% AR(3) calibration 
M3c     = [ x(1:end-3), x(2:end-2),  x(3:end-1) ];
theta3  = M3c \ x(4:end);
xc_3    = M3c * theta3;
xc_3    = [ x(1:3); xc_3 ];
qc_3    = xc_3 .* s_q + m_q;

e3 = q(4:end) - qc_3(4:end);

figure;
correlogram(e3,e3,20);

R2c_3 = 1 - sum((q(4:end)-qc_3(4:end)).^2) / sum((q(4:end )-m_q(4:end)).^2) 

% AR(3) validation
M3v  = [ xv(1:end-3), xv(2:end-2),  xv(3:end-1) ];
xv_3 = M3v * theta3;
xv_3 = [ xv(1:3); xv_3 ];
qv_3 = xv_3 .* s_qv + m_qv;
R2v_3 = 1 - sum((qv(4:end)-qv_3(4:end)).^2) / ...
    sum((qv(4:end)-m_qv(4:end)).^2 ) 



%  -----------
%%  ARX MODEL: exogenous models ARX(a,b,c) 
% a is the inflow
% b is the precipitation
% c is the temperature
%  -----------


%  ----------------------
% ARX(1,1,0) - proper model
%  ----------------------

%training

y = x(2:end);
M110 = [ x(1:end-1), u(1:end-1) ] ;  
theta_110pro    = M110 \ y;
x_110pro = [ x(1); M110 * theta_110pro ] ;
q_110pro = x_110pro .* s_q + m_q ;
R2_110pro = 1 - sum( (q( 2 : end ) - q_110pro( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M110v = [ xv(1:end-1), uv(1:end-1) ] ;  
x_110prov = [ xv(1); M110v * theta_110pro ] ;
q_110prov = x_110prov .* s_qv + m_qv ;
R2_110prov = 1 - sum( (qv( 2 : end ) - q_110prov( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_110pro = q(2:end) - q_110pro(2:end);
figure;
correlogram(e_110pro,e_110pro,20);

%  ----------------------
% ARX(1,1,0) - improper model
%  ----------------------

%training

y = x(2:end);
M110i = [ x(1:end-1), u(2:end) ] ;  
theta_110imp    = M110i \ y;
x_110imp = [ x(1); M110i * theta_110imp ] ;
q_110imp = x_110imp .* s_q + m_q ;
R2_110imp = 1 - sum( (q( 2 : end ) - q_110imp( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M110iv = [ xv(1:end-1), uv(2:end) ] ;  
x_110impv = [ x(1); M110iv * theta_110imp ] ;
q_110impv = x_110impv .* s_qv + m_qv ;
R2_110impv = 1 - sum( (qv( 2 : end ) - q_110impv( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_110impv = q(2:end) - q_110imp(2:end);
figure;
correlogram(e_110impv,e_110impv,20);

%  ----------------------
% ARX(1,1,1) - proper model
%  ----------------------

%training

y = x(2:end);
M111 = [ x(1:end-1), u(1:end-1), z(1:end-1) ] ;  
theta_111pro    = M111 \ y;
x_111pro = [ x(1); M111 * theta_111pro ] ;
q_111pro = x_111pro .* s_q + m_q ;
R2_111pro = 1 - sum( (q( 2 : end ) - q_111pro( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M111v = [ xv(1:end-1), uv(1:end-1), zv(1:end-1) ] ;  
x_111prov = [ xv(1); M111v * theta_111pro ] ;
q_111prov = x_111prov .* s_qv + m_qv ;
R2_111prov = 1 - sum( (qv( 2 : end ) - q_111prov( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_111pro = q(2:end) - q_111pro(2:end);
figure;
correlogram(e_111pro,e_111pro,20);

%  ----------------------
% ARX(1,1,1) - improper model
%  ----------------------

%training

y = x(2:end);
M111i = [ x(1:end-1), u(2:end), z(2:end)];  
theta_111imp    = M111i \ y;
x_111imp = [ x(1); M111i * theta_111imp ] ;
q_111imp = x_110imp .* s_q + m_q ;
R2_111imp = 1 - sum( (q( 2 : end ) - q_111imp( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M111iv = [ xv(1:end-1), uv(2:end),zv(2:end) ] ;  
x_111impv = [ x(1); M111iv * theta_111imp ] ;
q_111impv = x_111impv .* s_qv + m_qv ;
R2_111impv = 1 - sum( (qv( 2 : end ) - q_111impv( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_111impv = q(2:end) - q_111imp(2:end);
figure;
correlogram(e_111impv,e_111impv,20);


%  ----------------------
% ARX(2,1,0) - proper model
%  ----------------------

%training

y = x(3:end);
M210 = [ x(1:end-2), x(2:end-1),u(2:end-1) ] ;  
theta_210pro    = M210 \ y;
x_210pro = [ x(1);x(2); M210 * theta_210pro ] ;
q_210pro = x_210pro .* s_q + m_q ;
R2_210pro = 1 - sum( (q( 2 : end ) - q_210pro( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M210v = [ xv(1:end-2), xv(2:end-1),uv(2:end-1) ] ;  
x_210prov = [ xv(1);xv(2); M210v * theta_210pro ] ;
q_210prov = x_210prov .* s_qv + m_qv ;
R2_210prov = 1 - sum( (qv( 2 : end ) - q_210prov( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_210pro = q(3:end) - q_210pro(3:end);
figure;
correlogram(e_210pro,e_210pro,20);


%  ----------------------
% ARX(2,1,0) - improper model
%  ----------------------

%training

y = x(3:end);
M210i = [ x(1:end-2), x(2:end-1),u(3:end) ] ;  
theta_210imp    = M210i \ y;
x_210imp = [ x(1);x(2); M210i * theta_210imp ] ;
q_210imp = x_210imp .* s_q + m_q ;
R2_210imp = 1 - sum( (q( 2 : end ) - q_210imp( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M210iv = [ xv(1:end-2), xv(2:end-1),uv(3:end) ] ;  
x_210impv = [ xv(1);xv(2); M210iv * theta_210imp ] ;
q_210impv = x_210impv .* s_qv + m_qv ;
R2_210impv = 1 - sum( (qv( 2 : end ) - q_210impv( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_210pro = q(3:end) - q_210pro(3:end);
figure;
correlogram(e_210pro,e_210pro,20);


%  ----------------------
% ARX(2,1,1) - proper model
%  ----------------------

%training

y = x(3:end);
M211 = [ x(1:end-2), x(2:end-1),u(2:end-1),z(2:end-1) ] ;  
theta_211pro    = M211 \ y;
x_211pro = [ x(1);x(2); M211 * theta_211pro ] ;
q_211pro = x_211pro .* s_q + m_q ;
R2_211pro = 1 - sum( (q( 2 : end ) - q_211pro( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M211v = [ xv(1:end-2), xv(2:end-1),uv(2:end-1),zv(2:end-1) ] ;  
x_211prov = [ xv(1);xv(2); M211v * theta_211pro ] ;
q_211prov = x_211prov .* s_qv + m_qv ;
R2_211prov = 1 - sum( (qv( 2 : end ) - q_211prov( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_211pro = q(3:end) - q_211pro(3:end);
figure;
correlogram(e_211pro,e_211pro,20);

%  ----------------------
% ARX(2,1,1) - improper model
%  ----------------------

%training

y = x(3:end);
M211 = [ x(1:end-2), x(2:end-1),u(3:end),z(3:end) ] ;  
theta_211imp    = M211 \ y;
x_211imp = [ x(1);x(2); M211 * theta_211pro ] ;
q_211imp = x_211imp .* s_q + m_q ;
R2_211imp = 1 - sum( (q( 2 : end ) - q_211imp( 2 : end )).^2 ) / ...
    sum( (q( 2 : end )-m_q(2:end) ).^2 )

%validation

M211v = [ xv(1:end-2), xv(2:end-1),uv(3:end),zv(3:end) ] ;  
x_211impv = [ xv(1);xv(2); M211v * theta_211pro ] ;
q_211impv = x_211impv .* s_qv + m_qv ;
R2_211impv = 1 - sum( (qv( 2 : end ) - q_211impv( 2 : end )).^2 ) / ...
    sum( (qv( 2 : end )-m_qv(2:end) ).^2 )

e_211pro = q(3:end) - q_211pro(3:end);
figure;
correlogram(e_211pro,e_211pro,20);


%% LINEAR MODELS COMPARISON

%comparing all the models on a bar graph

bar([R2_A1 R2_A1v; R2c_2 R2v_2; R2c_3 R2v_3;
    R2_110pro R2_110prov; R2_110imp R2_110impv;
    R2_111pro R2_111prov; R2_111imp R2_111impv;
    R2_210pro R2_210prov; R2_210imp R2_210impv;
    R2_211pro R2_211prov;
    R2_211imp R2_211impv])
set(gca,'XTickLabel',{'AR(1)','AR(2)','AR(3)','ARX(1,1,0) pro','ARX(1,1,0) imp','ARX(1,1,1) pro','ARX(1,1,1) imp','ARX(2,1,0) pro','ARX(2,1,0) imp','ARX(2,1,1) pro','ARX(2,1,1) imp'})
title('LINEAR MODELS COMPARISON')
axis([0.3 12 0.9 1])

%% Non Linear Models

%% ANN SINGLE RUN

% ----------------
%  ANN PROPER 1 1 0
% ----------------

% training
Xp = [ x(1:end-1) u(1:end-1) ];
Yp = x(2:end);
net = feedforwardnet(5);
% 1 hidden layer with 5 neurons - view(net)
net = train(net, Xp', Yp');
Y_p = [ x(1) ; net(Xp')' ] ;
q_ann_pro = Y_p .* s_q + m_q ;

R2_ann_pro = 1 - sum((q(2:end)-q_ann_pro(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xpv = [ xv(1:end-1) uv(1:end-1) ];
Y_pv = [ xv(1) ; net(Xpv')' ];
q_ann_prov = Y_pv .* s_qv + m_qv;

R2_ann_prov = 1 - sum((qv(2:end)-q_ann_prov(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)



% ----------------
%  ANN IMPROPER 1 1 0
% ----------------

% training
Xi = [ x(1:end-1) u(2:end) ];
Yi = x(2:end);
net = feedforwardnet(5);
% 1 hidden layer with 5 neurons - view(net)
net = train(net, Xi', Yi');
Y_i = [ x(1) ; net(Xi')' ];
q_ann_imp = Y_i .* s_q + m_q;

R2_ann_imp = 1 - sum((q(2:end)-q_ann_imp(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xiv = [ xv(1:end-1) uv(2:end) ];
Y_iv = [ xv(1) ; net(Xiv')' ];
q_ann_impv = Y_iv .* s_qv + m_qv;

R2_ann_impv = 1 - sum((qv(2:end)-q_ann_impv(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

%
%% ANN (1) shallow and deep (switch as per need)

N_runs = 15;
X1 = x(1:end-1);
Y1 = x(2:end);
X1v = [ xv(1:end-1) ];
R2_ann1 = zeros(N_runs,2); %to make runs faster

for i=1:N_runs
    
    net1 = feedforwardnet(5);               % 1 hidden layer with 5 neurons - view(net)
  % net1 = feedforwardnet([5 5 5 5]);    % 4 hidden layers with 5 neurons each)
    net1 = train(net1, X1', Y1');
    Y_1 = [ x(1) ; net1(X1')' ] ;
    q_ann1 = Y_1 .* s_q + m_q ;

    R2_ann1(i,1) = 1 - sum((q(2:end)-q_ann1(2:end)).^2) / ...
            sum((q(2:end)-m_q(2:end)).^2)

    % validation

    Y_1v = [ xv(1) ; net1(X1v')' ];
    q_ann1v = Y_1v .* s_qv + m_qv;

    R2_ann1(i,2) = 1 - sum((qv(2:end)-q_ann1v(2:end)).^2) / ...
            sum((qv(2:end)-m_qv(2:end)).^2)

    if R2_ann1(i,2)>=max(R2_ann1(:,2))      % saving the best model (in test) as net_ann1
        net_ann1 = net1;
    end
end

Y_ann1 = [x(1);net_ann1(X1')'];
q_ann1_ = Y_ann1.*s_q + m_q;

Y_ann1_v = [xv(1);net_ann1(X1v')'];
q_ann1_v = Y_ann1_v.*s_qv + m_qv;

e_ann1 = q(2:end) - q_ann1_(2:end);
figure;
correlogram(e_ann1,e_ann1,20);

[R2_ann1_v,idx] = max(R2_ann1(:,2));
R2_ann1_= R2_ann1(idx,1);
figure
bar(R2_ann1)


%% ANN (2) shallow and deep (switch as per need)

N_runs = 15;
X2 = [x(1:end-2),x(2:end-1)];
Y2 = x(3:end);
X2v = [ xv(1:end-2), xv(2:end-1) ];
R2_ann2 = zeros(N_runs,2); %to make runs faster

for i=1:N_runs
    
    net2 = feedforwardnet(5);               % 1 hidden layer with 5 neurons - view(net)
  % net2 = feedforwardnet([5 5 5 5]);    % 4 hidden layers with 5 neurons each)
    net2 = train(net2, X2', Y2');
    Y_2 = [ x(1); x(2); net2(X2')' ] ;
    q_ann2 = Y_2 .* s_q + m_q ;

    R2_ann2(i,1) = 1 - sum((q(2:end)-q_ann2(2:end)).^2) / ...
            sum((q(2:end)-m_q(2:end)).^2)

    % validation

    Y_2v = [ xv(1);xv(2) ; net2(X2v')' ];
    q_ann2v = Y_2v .* s_qv + m_qv;

    R2_ann2(i,2) = 1 - sum((qv(2:end)-q_ann2v(2:end)).^2) / ...
            sum((qv(2:end)-m_qv(2:end)).^2)

    if R2_ann2(i,2)>=max(R2_ann2(:,2))              % saving the best model (in test) as net_ann2
        net_ann2 = net2;
    end
end

Y_ann2 = [x(1);x(2);net_ann2(X2')'];
q_ann2_ = Y_ann2.*s_q + m_q;

Y_ann2_v = [xv(1);xv(2);net_ann2(X2v')'];
q_ann2_v = Y_ann2_v.*s_qv + m_qv;

e_ann2v = qv(3:end) - q_ann2_v(3:end);
figure;
correlogram(e_ann2v,e_ann2v,20);

[R2_ann2_v,idx] = max(R2_ann2(:,2));
R2_ann2_= R2_ann2(idx,1);

figure
bar(R2_ann2)

%% ANN (3) shallow and deep (switch as per need)

N_runs = 15; 
X3 = [x(1:end-3),x(2:end-2),x(3:end-1)];
Y3 = x(4:end);
X3v = [xv(1:end-3),xv(2:end-2),xv(3:end-1)];
R2_ann3 = zeros(N_runs,2); %to make runs faster

for i=1:N_runs
    
    net3 = feedforwardnet(5);               % 1 hidden layer with 10 neurons - view(net)
  % net3 = feedforwardnet([5 5 5 5]);    % 4 hidden layers with 10 neurons each)
    net3 = train(net3, X3', Y3');
    Y_3 = [ x(1); x(2);x(3); net3(X3')' ] ;
    q_ann3 = Y_3 .* s_q + m_q ;

    R2_ann3(i,1) = 1 - sum((q(2:end)-q_ann3(2:end)).^2) / ...
            sum((q(2:end)-m_q(2:end)).^2)

    % validation

    Y_3v = [ xv(1); xv(2); xv(3) ; net3(X3v')' ];
    q_ann3v = Y_3v .* s_qv + m_qv;

    R2_ann3(i,2) = 1 - sum((qv(2:end)-q_ann3v(2:end)).^2) / ...
            sum((qv(2:end)-m_qv(2:end)).^2)

    if R2_ann3(i,2)>=max(R2_ann3(:,2))      % saving the best model (in test) as net_ann3
        net_ann3 = net3;
    end
end

Y_ann3 = [x(1);x(2);x(3);net_ann3(X3')'];
q_ann3_ = Y_ann3.*s_q + m_q;

Y_ann3_v = [xv(1);xv(2);xv(3);net_ann3(X3v')'];
q_ann3_v = Y_ann3_v.*s_qv + m_qv;

e_ann3v = qv(4:end) - q_ann3_v(4:end);
figure;
correlogram(e_ann3v,e_ann3v,20);

[R2_ann3_v,idx] = max(R2_ann3(:,2));
R2_ann3_= R2_ann3(idx,1);

figure
bar(R2_ann3)

%%  ANN PROPER shallow (1 1 0)
% --------------
Nn = [5 10 15 20 ];

N_runs = 20;

Xs = [ x(1:end-1) u(1:end-1) ];
Ys = x(2:end);
Xsv = [ xv(1:end-1) uv(1:end-1) ]
R2_anns_pro = zeros(length(Nn),N_runs);   %to make runs faster
R2_anns_prov = zeros(length(Nn),N_runs);  %to make runs faster

for j = 1:N_runs
    for i=1:length(Nn)  

        net_anns = feedforwardnet(Nn(i));
        net_anns = train(net_anns,Xs',Ys');
        Y_s = [x(1);net_anns(Xs')']; 

        q_anns_pro = Y_s.*s_q + m_q;

        R2_anns_pro(i,j) = 1 - sum((q(2:end)-q_anns_pro(2:end)).^2) / ...
            sum((q(2:end)-m_q(2:end)).^2);

        % ANN(1,1,0) proper : validation

        Y_sv = [xv(1);net_anns(Xsv')'];
        q_anns_prov = Y_sv.*s_qv + m_qv;

        R2_anns_prov(i,j) = 1 - sum((qv(2:end)-q_anns_prov(2:end)).^2) / ...
            sum((qv(2:end)-m_qv(2:end)).^2);
    end
end

figure;
plot(R2_anns_prov(1,:))
hold on
plot(R2_anns_prov(2,:))
plot(R2_anns_prov(3,:))
plot(R2_anns_prov(4,:))
legend('Nn = 5','Nn = 10','Nn = 15','Nn = 20');

[R2_anns_pv,idx] = max(R2_anns_prov(1,:))
 R2_anns_p= R2_anns_pro(1,idx)
% ----------------
%%  ANN IMPROPER shallow ( 1 1 0)
% ----------------


Xsi = [ x(1:end-1) u(1:end-1) ];
Ysi = x(2:end);
X_svi = [ xv(1:end-1) uv(1:end-1) ];
R2_anns_imp = zeros(length(Nn),N_runs);   %to make runs faster
R2_anns_impv = zeros(length(Nn),N_runs);  %to make runs faster

for j = 1:N_runs
    for i=1:length(Nn)  

        net_s_imp = feedforwardnet(Nn(i));
        net_s_imp = train(net_s_imp,Xsi',Ysi');
        Y_si = [x(1);net_s_imp(Xsi')']; 

        q_anns_imp = Y_si.*s_q + m_q;

        R2_anns_imp(i,j) = 1 - sum((q(2:end)-q_anns_imp(2:end)).^2) / ...
            sum((q(2:end)-m_q(2:end)).^2);

        % ANN(1,1,0) proper : validation

        Y_svi = [xv(1);net_s_imp(Xsv')'];
        q_anns_impv = Y_svi.*s_qv + m_qv;

        R2_anns_impv(i,j) = 1 - sum((qv(2:end)-q_anns_impv(2:end)).^2) / ...
            sum((qv(2:end)-m_qv(2:end)).^2);
    end
end

figure;
plot(R2_anns_impv(1,:))
hold on
plot(R2_anns_impv(2,:))
plot(R2_anns_impv(3,:))
plot(R2_anns_impv(4,:))
legend('Nn = 5','Nn = 10','Nn = 15','Nn = 20');

[R2_anns_iv,idx] = max(R2_anns_impv(1,:))
 R2_anns_i= R2_anns_imp(1,idx)
%%  ANN PROPER deep (1 1 0)
% --------------


Xd = [x(1:end-1),u(1:end-1)];
Yd = x(2:end);
X_dv = [xv(1:end-1),uv(1:end-1)];
R2_annd_pro = zeros(N_runs,2);   %to make runs faster


for i=1:N_runs
    
    % training
    net_d_pro = feedforwardnet([5 5 5 5]);
    net_d_pro = train(net_d_pro,Xd',Yd');
    Y_d = [x(1);net_d_pro(Xd')'];
    q_annd_pro = Y_d.*s_q + m_q;

    R2_annd_pro(i,1) = 1 - sum((q(2:end)-q_annd_pro(2:end)).^2) / ...
                sum((q(2:end)-m_q(2:end)).^2);

    % validation

    Y_dv = [xv(1);net_d_pro(X_dv')'];
    q_annd_prov = Y_dv.*s_qv + m_qv;

    R2_annd_pro(i,2) = 1 - sum((qv(2:end)-q_annd_prov(2:end)).^2) / ...
                sum((qv(2:end)-m_qv(2:end)).^2);
            
    if R2_annd_pro(i,2)>=max(R2_annd_pro(:,2))      % saving the best model (in test) as net_annd
        net_annd = net_d_pro;
    end
    
end


[R2_annd_pv,idx] = max(R2_annd_pro(:,2))
R2_annd_p = R2_annd_pro(idx,1)

%% ANN IMPROPER deep (1,1,0)   


Xdi = [x(1:end-1),u(2:end)];
Ydi = x(2:end);
X_dvi = [xv(1:end-1),uv(2:end)];
R2_annd_imp = zeros(N_runs,2);   %to make runs faster

for i =1:N_runs
    
    % training
    net_d_imp = feedforwardnet([5 5 5 5]);
    net_d_imp = train(net_d_imp,Xdi',Ydi');
    Y_annd_imp = [x(1);net_d_imp(Xdi')'];
    q_annd_imp = Y_annd_imp.*s_q + m_q;

    R2_annd_imp(i,1) = 1 - sum((q(2:end)-q_annd_imp(2:end)).^2) / ...
                sum((q(2:end)-m_q(2:end)).^2);


    % validation

    Y_annd_impv = [xv(1);net_d_imp(X_dvi')'];
    q_annd_impv = Y_annd_impv.*s_qv + m_qv;

    R2_annd_imp(i,2) = 1 - sum((qv(2:end)-q_annd_impv(2:end)).^2) / ...
                sum((qv(2:end)-m_qv(2:end)).^2);
            
    if R2_annd_imp(i,2)>=max(R2_annd_imp(:,2))      % saving the best model (in test) as net_annd_imp
        net_annd_imp = net_d_imp;
    end
    
end

[R2_annd_iv,idx] = max(R2_annd_imp(:,2))
R2_annd_i = R2_annd_imp(idx,1)


% ---------------------
%%  ANN MODELS COMPARISON
% ---------------------

figure
bar([R2_ann_pro R2_ann_prov; R2_ann_imp R2_ann_impv])
set(gca, 'XTickLabel',{'ANN pro', 'ANN imp'})
title('ANN Single Run MODEL COMPARISON')
axis([0.5 4 0.9 1])

figure
bar([R2_ann1_ R2_ann1_v; R2_ann2_ R2_ann2_v; R2_ann3_ R2_ann3_v])
set(gca, 'XTickLabel',{'ANN(1)', 'ANN (2)','ANN (3)'})
title('ANN MODEL COMPARISON')
axis([0.5 4 0.9 1])

figure
bar([R2_anns_p R2_anns_pv; R2_anns_i R2_anns_iv; R2_annd_p R2_annd_pv ;R2_annd_i R2_annd_iv])
set(gca, 'XTickLabel',{'ANN shallow proper(1 1 0)', 'ANN shallow improper(1 1 0)','ANN deep proper(1 1 0)', 'ANN deep improper(1 1 0)'})
title('ANN MODEL COMPARISON')
axis([0.5 6 0.9 1])



% -----------------------------

%%  CART Models

% ------------------------
% Cart 1 1 0 proper
% ------------------------

Xcp = [x(1:end-1), u(1:end-1)];
Ycp = x(2:end);
ls = 10;        %leaf size

% training
T1 = fitrtree(Xcp, Ycp, 'MinLeafSize', ls);
%view(T1, 'mode', 'graph')      % to view the Regression Tree

Y_pro = [ x(1); predict(T1, Xcp) ];
q_cart_pro = Y_pro .* s_q + m_q;
R2_cart_pro = 1 - sum((q(2:end)-q_cart_pro(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xvcp = [xv(1:end-1), uv(1:end-1)];
Yvcp = xv(2:end);
Y_c = predict(T1, Xvcp);
Yvc_pro = [ xv(1); Y_c ] ;
qv_cart_pro = Yvc_pro .* s_qv + m_qv ;
R2_cart_prov = 1 - sum((qv(2:end)-qv_cart_pro(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

figure
plot(q,'.-')
hold on
plot(q_cart_pro,'.-')
legend('Observed','CART 110 proper');

% note that length(unique(Y_)) is equal to the number of leaves
% optimization of minLeafSize
% Topt = fitrtree(X, Y, 'OptimizeHyperparameters', 'auto')

% test pruning
% Tpruned = prune(T, 'Alpha', 0.2);

% ------------------------
% Cart 1 1 0 improper
% ------------------------

Xci = [x(1:end-1), u(2:end)];
Yci = x(2:end);

% training
T1i = fitrtree(Xci, Yci, 'MinLeafSize', ls);
%view(T1i, 'mode', 'graph')      % to view the Regression Tree

Y_imp = [ x(1); predict(T1i, Xci) ];
q_cart_imp = Y_imp .* s_q + m_q;
R2_cart_imp = 1 - sum((q(2:end)-q_cart_imp(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xvci = [xv(1:end-1), uv(1:end-1)]; 
Yvci = xv(2:end);
Y_ci = predict(T1i, Xvci);
Yvc_imp = [ xv(1); Y_ci ] ;
qv_cart_imp = Yvc_imp .* s_qv + m_qv ;
R2_cart_impv = 1 - sum((qv(2:end)-qv_cart_imp(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

figure
plot(q,'.-')
hold on
plot(q_cart_imp,'.-')
legend('Observed','CART 110 improper');

% ------------------------
% CART 2 1 0 proper
% ------------------------

Xc1p = [x(1:end-2),x(2:end-1),u(2:end-1)];
Yc1p = x(3:end);

% training
T2 = fitrtree(Xc1p, Yc1p, 'MinLeafSize', ls);
%view(T1, 'mode', 'graph')      % to view the Regression Tree

Y_1pro = [ x(1);x(2); predict(T2, Xc1p) ];
q_cart_1pro = Y_1pro .* s_q + m_q;
R2_cart_1pro = 1 - sum((q(2:end)-q_cart_1pro(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xvc1p = [xv(1:end-2),xv(2:end-1),uv(2:end-1)];
Yvc_1pro = [xv(1);xv(2);predict(T2,Xvc1p)] ;
qv_cart_1pro = Yvc_1pro .* s_qv + m_qv ;
R2_cart_1prov = 1 - sum((qv(2:end)-qv_cart_1pro(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_cart_1pro,'.-')
% legend('Observed','CART 210 proper');

% ------------------------
% CART 2 1 0 improper
% ------------------------

Xc1i = [x(1:end-2),x(2:end-1),u(3:end)];
Yc1i = x(3:end);

% training
T2 = fitrtree(Xc1i, Yc1i, 'MinLeafSize', ls);
%view(T1, 'mode', 'graph')      % to view the Regression Tree

Y_1imp = [ x(1);x(2); predict(T2, Xc1i) ];
q_cart_1imp = Y_1imp .* s_q + m_q;
R2_cart_1imp = 1 - sum((q(2:end)-q_cart_1imp(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xvc1i = [xv(1:end-2),xv(2:end-1),uv(2:end-1)];
Yvc_1imp = [xv(1);xv(2);predict(T2,Xvc1i)] ;
qv_cart_1imp = Yvc_1imp .* s_qv + m_qv ;
R2_cart_1impv = 1 - sum((qv(2:end)-qv_cart_1imp(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_cart_1imp,'.-')
% legend('Observed','CART 210 improper');
%%
% ------------------------
% CART(1) 
% ------------------------
% training

X_cart1 = x(1:end-1);
Y_cart1 = x(2:end);
Tc1 = fitrtree(X_cart1,Y_cart1,'MinLeafSize',ls);
Y_cart1_ = [x(1);predict(Tc1,X_cart1)];

q_cart1 = Y_cart1_.*s_q + m_q;

R2_cart1 = 1 - sum((q(2:end)-q_cart1(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
X_cart1v = xv(1:end-1);
Y_cart1v = [xv(1);predict(Tc1,X_cart1v)];
q_cart1v = Y_cart1v.*s_qv + m_qv;

R2_cart1v = 1 - sum((qv(2:end)-q_cart1v(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_cart1,'.-')
% legend('Observed','CART(1)');

% ------------------------
% CART(2) 
% ------------------------
% training

X_cart2 = [x(1:end-2),x(2:end-1)];
Y_cart2 = x(3:end);
Tc2 = fitrtree(X_cart2,Y_cart2,'MinLeafSize',ls);
Y_cart2_ = [x(1);x(2);predict(Tc2,X_cart2)];

q_cart2 = Y_cart2_.*s_q + m_q;

R2_cart2= 1 - sum((q(3:end)-q_cart2(3:end)).^2) / ...
    sum((q(3:end)-m_q(3:end)).^2)

% validation
X_cart2v = [xv(1:end-2),xv(2:end-1)];
Y_cart2v = [xv(1);xv(2);predict(Tc2,X_cart2v)];
q_cart2v = Y_cart2v.*s_qv + m_qv;

R2_cart2v = 1 - sum((qv(3:end)-q_cart2v(3:end)).^2) / ...
    sum((qv(3:end)-m_qv(3:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_cart2,'.-')
% legend('Observed','CART(2)');


% ------------------------
% CART(3) : training
% ------------------------

X_cart3 = [x(1:end-3),x(2:end-2),x(3:end-1)];
Y_cart3 = x(4:end);
Tc3 = fitrtree(X_cart3,Y_cart3,'MinLeafSize',ls);
Y_cart3_ = [x(1);x(2);x(3);predict(Tc3,X_cart3)];

q_cart3 = Y_cart3_.*s_q + m_q;

R2_cart3 = 1 - sum((q(4:end)-q_cart3(4:end)).^2) / ...
    sum((q(4:end)-m_q(4:end)).^2)

% validation
X_cart3v = [xv(1:end-3),xv(2:end-2),xv(3:end-1)];
Y_cart3v = [xv(1);xv(2);xv(3);predict(Tc3,X_cart3v)];
q_cart3v = Y_cart3v.*s_qv + m_qv;

R2_cart3v = 1 - sum((qv(4:end)-q_cart3v(4:end)).^2) / ...
    sum((qv(4:end)-m_qv(4:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_cart3,'.-')
% legend('Observed','CART(3)');
% ------------------------
%%  RANDOM FOREST (switch bagging/boosting)

% ------------------------
%   RANDOM FOREST PROPER 1 1 0
% ------------------------

% training
t = templateTree('MinLeafSize', ls);
RF = fitrensemble(Xcp, Ycp, 'Method', 'Bag', ...  %choose the bagging/boosting here
    'Learners', t, ...
    'NumLearningCycles', 20);

Y_pro = [ x(1); predict(RF, Xcp) ];
q_RF_pro = Y_pro .* s_q + m_q ;
R2_RF_pro = 1 - sum((q(2:end)-q_RF_pro(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Yvc_pro = [ xv(1); predict(RF, Xvcp) ];
qv_RF_pro = Yvc_pro .* s_qv + m_qv;
R2_RF_prov = 1 - sum((qv(2:end)-qv_RF_pro(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_RF_pro,'.-')
% legend('Observed','RF(110) proper');
% ------------------------

% --------------------------
%  RANDOM FOREST IMPROPER 1 1 0
% --------------------------

Xci = [x(1:end-1), u(2:end)];

% training
t = templateTree('MinLeafSize', ls);
RF = fitrensemble(Xci, Yci, 'Method', 'Bag', ...
    'Learners', t, ...
    'NumLearningCycles', 20);
Y_imp = [ x(1); predict(RF, Xci) ];
q_RF_imp = Y_imp .* s_q + m_q ;
R2_RF_imp = 1 - sum((q(2:end)-q_RF_imp(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Xvip = [xv(1:end-1), uv(2:end)];
Yvip = xv(2:end);
Yv_imp = [ xv(1); predict(RF, Xvip) ];
qv_RF_imp = Yv_imp .* s_qv + m_qv;
R2_RF_impv = 1 - sum((qv(2:end)-qv_RF_imp(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_RF_imp,'.-')
% legend('Observed','RF(110) improper');

% --------------------
%  RANDOM FOREST PROPER 2 1 0
% --------------------

% training
t = templateTree('MinLeafSize', ls);
RF = fitrensemble(Xc1p, Yc1p, 'Method', 'Bag', ...  %choose the bagging/boosting here
    'Learners', t, ...
    'NumLearningCycles', 20);

Y_210pro = [ x(1);x(2); predict(RF, Xc1p) ];
q_RF_210pro = Y_210pro .* s_q + m_q ;
R2_RF_210pro = 1 - sum((q(2:end)-q_RF_210pro(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Yvc_210pro = [ xv(1);xv(2); predict(RF, Xvc1p) ];
qv_RF_210pro = Yvc_210pro .* s_qv + m_qv;
R2_RF_210prov = 1 - sum((qv(2:end)-qv_RF_210pro(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_RF_210pro,'.-')
% legend('Observed','RF(210) proper');


% --------------------
%  RANDOM FOREST IMPROPER 2 1 0
% --------------------

% training
t = templateTree('MinLeafSize', ls);
RF = fitrensemble(Xc1i, Yc1i, 'Method', 'Bag', ...  %choose the bagging/boosting here
    'Learners', t, ...
    'NumLearningCycles', 20);

Y_210imp = [ x(1);x(2); predict(RF, Xc1i) ];
q_RF_210imp = Y_210imp .* s_q + m_q ;
R2_RF_210imp = 1 - sum((q(2:end)-q_RF_210imp(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% validation
Yvc_210imp = [ xv(1);xv(2); predict(RF, Xvc1i) ];
qv_RF_210imp = Yvc_210imp .* s_qv + m_qv;
R2_RF_210impv = 1 - sum((qv(2:end)-qv_RF_210imp(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_RF_210imp,'.-')
% legend('Observed','RF(210) improper');


%%

% --------------------
%  RANDOM FOREST (1)
% --------------------

% training

RF_1 = fitrensemble(X_cart1,Y_cart1,'Method','Bag',...
    'Learners',t,...
    'NumLearningCycles',20);

Y_rf1 = [x(1);predict(RF_1,X_cart1)];
q_rf1 = Y_rf1.*s_q + m_q;
R2_rf1 = 1 - sum((q(2:end)-q_rf1(2:end)).^2) / ...
    sum((q(2:end)-m_q(2:end)).^2)

% TE(1) : validation

Y_rf1v = [xv(1);predict(RF_1,X_cart1v)];
q_rf1v = Y_rf1v.*s_qv + m_qv;

R2_rf1v = 1 - sum((qv(2:end)-q_rf1v(2:end)).^2) / ...
    sum((qv(2:end)-m_qv(2:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_rf1,'.-')
% legend('Observed','RF(1)');

%% --------------------
%  RANDOM FOREST (2)
% --------------------
% training

RF_2 = fitrensemble(X_cart2,Y_cart2,'Method','Bag',...
    'Learners',t,...
    'NumLearningCycles',20);

Y_rf2 = [x(1);x(2);predict(RF_2,X_cart2)];

q_rf2 = Y_rf2.*s_q + m_q;

R2_rf2 = 1 - sum((q(3:end)-q_rf2(3:end)).^2) / ...
    sum((q(3:end)-m_q(3:end)).^2)

% validation

Y_rf2v = [xv(1);xv(2);predict(RF_2,X_cart2v)];
q_rf2v = Y_rf2v.*s_qv + m_qv;
R2_rf2v = 1 - sum((qv(3:end)-q_rf2v(3:end)).^2) / ...
    sum((qv(3:end)-m_qv(3:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_rf2,'.-')
% legend('Observed','RF(2)');

%% --------------------
%  RANDOM FOREST (3)
% --------------------

% training

RF_3 = fitrensemble(X_cart3,Y_cart3,'Method','Bag',...
    'Learners',t,...
    'NumLearningCycles',20);

Y_rf3 = [x(1);x(2);x(3);predict(RF_3,X_cart3)];
q_rf3 = Y_rf3.*s_q + m_q;
R2_rf3 = 1 - sum((q(4:end)-q_rf3(4:end)).^2) / ...
    sum((q(4:end)-m_q(4:end)).^2)

% validation

Y_rf3v = [xv(1);xv(2);xv(3);predict(RF_3,X_cart3v)];
q_rf3v = Y_rf3v.*s_qv + m_qv;
R2_rf3v = 1 - sum((qv(4:end)-q_rf3v(4:end)).^2) / ...
    sum((qv(4:end)-m_qv(4:end)).^2)

% figure
% plot(q,'.-')
% hold on
% plot(q_rf3,'.-')
% legend('Observed','RF(3)');

%% PART 2
% 
 clear             % comment these 3 to run the part separately
 close all
 clc
% -----------------------------------
%%
data = readmatrix('10Freudenau.csv'); 
n = data(:,5);
qMonth = dailyToMonthly(n, 27); %m3/s

%target

w = prctile(n,17);

deltaT = 60*60*24*[31 28 31 30 31 30 31 31 30 31 30 31]'; 
% deltaT contains the number of seconds in each month
Q = qMonth(:) .* repmat(deltaT, 27, 1); % m3/month
W = w*ones(size(Q)) .* repmat(deltaT, 27, 1); % m3/month

figure
plot(Q); hold on; plot(W)

K = zeros(size(Q));

for t = 1:length(Q)
    K(t+1) = max(0, K(t) + W(t) - Q(t));
end

figure; plot(K)
Kopt = max(K)

% -----------------------------------
%%  LOAD THE PARAMETERS OF THE LAKE
% -----------------------------------
load -ascii 'lake_mod_param.txt'
% 700000000			  % S    (lake surface [m2] = 640 [km2])
% 153.6815068        % beta (storage-discharge relationship)
% 1        % alfa (storage-discharge relationship)
% 0                   % h0   (storage-discharge relationship)
param.nat.S = lake_mod_param(1);
param.nat.beta = lake_mod_param(2);
param.nat.alpha = lake_mod_param(3);
param.nat.h0 = lake_mod_param(4);
load -ascii 'lake_mod_param.txt'
% regulated level-discharge relationship:
param.reg.w = prctile(n,17);
param.reg.h_min = 0;
param.reg.h_max = Kopt/param.nat.S;
param.reg.h1 = 1.15;
param.reg.h2 = 2.65;
param.reg.m1 = 1250;
param.reg.m2 = 4750;

% --------------------------------------------
%%  SIMULATION OF NATURAL AND REGULATED LAKE
% --------------------------------------------
% reference of natural lake 
n = data(:,5);
n = [ nan; n ]; % for time convention
h_init =1.6; % initial condition

[s_nat, h_nat, r_nat] = simulate_nat_lake( n, h_init, param );
[s_reg, h_reg, r_reg] = simulate_reg_lake( n, h_init, param );

figure
subplot(211)
plot([h_nat h_reg]); ylabel('level (m)'); legend('nat', 'reg')
subplot(212)
plot([r_nat r_reg]); ylabel('release (m3/2)'); legend('nat', 'reg')

w = param.reg.w;
h_flo = 3;
h_nat = h_nat(2:end);
r_nat = r_nat(2:end);
% natural flow irrigation indicator
dn = max( w-r_nat, 0 );
Iirr_nat = mean( dn.^2 )
% regulated flow flooding indicator
Ny = length(h_nat)/365
Iflo_nat = sum( h_nat>h_flo )/Ny

LP = prctile(n, 20) % thresholds are defined over the inflow
HP = prctile(n, 80) % thresholds are defined over the inflow 

% natural flow environmental conditions (using inflow)
IE_nat = (sum( n < LP)+ sum( n > HP ))/Ny


h_reg = h_reg(2:end);
r_reg = r_reg(2:end);
% natural flow irrigation indicator
dr = max( w-r_reg, 0 );
Iirr_reg = mean( dr.^2 )
% regulated flow flooding indicator
Ny = length(h_reg)/365
Iflo_reg = sum( h_reg>h_flo )/Ny

% regulated flow environmental conditions (using regulated release)
IE_reg = (sum( r_reg < LP)+sum(r_reg > HP))/Ny


figure
plot3( Iflo_nat, Iirr_nat, IE_nat, 'bo')
hold on
plot3( Iflo_reg, Iirr_reg, IE_reg, 'ro')
xlabel('flood'); ylabel('irrigation'); zlabel('environmental')
legend('nat', 'reg')

% ------------------------------------------
%%  NSGAII-EMODPS OPTIMIZATION
% ------------------------------
global opt_inputs;
opt_inputs.n = n;
opt_inputs.h_init = h_init;
opt_inputs.param = param;
opt_inputs.h_flo = h_flo;
opt_inputs.LP = LP;
opt_inputs.HP = HP;
pop = 90;
gen = 15;
M = 3;
V = 4;
min_range = [ 0.5 2 1250 3500 ];
max_range = [ 2 3.78 3000 6000 ];
[ chromosome_0, chromosome15 ] = nsga_2(pop,gen,M,V,min_range,max_range);

% objective space
figure
plot3( chromosome_0(:,6), chromosome_0(:,5), chromosome_0(:,7),  'o')
xlabel('level')
ylabel('release')
zlabel('environmental')
% col 5 = irrigation, col 6 = flood
hold on
plot3( chromosome15(:,6), chromosome15(:,5),chromosome15(:,7), 'ro')
xlabel('flood'); ylabel('irrigation'); zlabel('environmental')
% decision space
h_test = [ 0 : 0.1 : 4.5 ];  
r_test = nan(pop, length(h_test));

for i = 1:pop
    xi = chromosome15(i,1:4);
    param.reg.h1 = xi(1);
    param.reg.h2 = xi(2);
    param.reg.m1 = xi(3);
    param.reg.m2 = xi(4);
    r_test(i,:) = regulated_release( param, h_test );
end

figure
plot( h_test, r_test )
xlabel('level')
ylabel('release')

%---------------------------------------End--------------------------------
%__________________________________________________________________________
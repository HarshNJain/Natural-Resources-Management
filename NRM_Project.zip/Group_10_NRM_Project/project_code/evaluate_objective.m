function f = evaluate_objective(x, M, V)
%
% function f = evaluate_objective(x, M, V)
%
% Function to evaluate the objective functions for the given input vector x.%
% x is an array of decision variables and f(1), f(2), etc are the
% objective functions. The algorithm always minimizes the objective
% function hence if you would like to maximize the function then multiply
% the function by negative one. M is the numebr of objective functions and
% V is the number of decision variables. 
%
% This functions is basically written by the user who defines his/her own
% objective function. Make sure that the M and V matches your initial user
% input.
%

x = x(1:V) ;
x = x(:)   ;

% --------------------------------------
% insert here your function:

% global variable to pass inside extra inputs
global opt_inputs ;
n = opt_inputs.n ;
h_init = opt_inputs.h_init ;
param = opt_inputs.param;
h_flo = opt_inputs.h_flo; 
LP = opt_inputs.LP;
HP = opt_inputs.HP;

% policy param
param.reg.h1 = x(1);
param.reg.h2 = x(2);
param.reg.m1 = x(3);
param.reg.m2 = x(4);

% run simulation
[s_reg, h_reg, r_reg] = simulate_reg_lake( n, h_init, param );

h_reg = h_reg(2:end);
r_reg = r_reg(2:end);
w = param.reg.w;

% natural flow irrigation indicator
dr = max( w-r_reg, 0 );
Iirr_reg = mean( dr.^2 )
% regulated flow flooding indicator
Ny = length(h_reg)/365
Iflo_reg = sum( h_reg>h_flo )/Ny

% regulated flow environmental conditions (using regulated release)
IE_reg = (sum( r_reg < LP)+ sum( r_reg > HP ))/Ny


f = [Iirr_reg, Iflo_reg, IE_reg];

% --------------------------------------

% Check for error
if length(f) ~= M
    error('The number of decision variables does not match you previous input. Kindly check your objective function');
end
function [s, h, r] = simulate_nat_lake( n, h_init, param ) 
delta = 60*60*24;
H = length(n)-1 ; % 10 years horizon

% initialization of vectors of the trajectories
% preallocation speeds up the computation
s = nan( size(n) );
h = nan( size(n) );
r = nan( size(n) );

% initial condition t=1
h(1) = h_init; 
s(1) = h_init * param.nat.S;

% for loop
for t=1:H
   % 1) compute release from level
   r(t+1) = param.nat.beta*(h(t)-param.nat.h0).^param.nat.alpha
   
   % 2) compute mass-balance
   s(t+1) = s(t) + ( n(t+1) - r(t+1) )*delta;
   % remember that n and r are in m^3/s.
   % The mass-balance is at a daily scale
   
   % 3) compute level from storage
   h(t+1) = s(t+1)/param.nat.S;
end